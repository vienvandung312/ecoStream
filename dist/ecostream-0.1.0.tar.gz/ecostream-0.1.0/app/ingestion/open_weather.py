import os
import requests
from dotenv import load_dotenv
from constants import WorkingPath

load_dotenv(WorkingPath.ROOT / '.env')
OPEN_WEATHER_API_KEY = os.getenv('OPEN_WEATHER_API_KEY')
OPEN_WEATHER_API_URL = "https://api.openweathermap.org/data/2.5/{endpoint}?lat={lat}&lon={lon}&appid={api_key}"
GEOCODING_API_URL = "https://api.openweathermap.org/geo/1.0/direct?q={city_name}&appid={api_key}"

def get_coordinates_by_name(city_name: str) -> dict:
    response = requests.get(f"{GEOCODING_API_URL.format(city_name, api_key=OPEN_WEATHER_API_KEY)}")
    return response.json()

get_coordinates_by_name("Vietnam")