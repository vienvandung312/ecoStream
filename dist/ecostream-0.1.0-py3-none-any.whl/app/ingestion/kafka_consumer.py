from json import loads
import os
from kafka import KafkaConsumer

